
<?php
class Store_model extends CI_Model {

    public function save_store($data) {
        // Save the store
        $this->db->insert('stores', $data);
        $store_id = $this->db->insert_id();

        // Auto-create default warehouse
        $warehouse_data = array(
            'warehouse_name' => $data['store_name'],
            'store_id' => $store_id,
            'user_id' => $data['user_id'], // Must be passed in $data
            'is_default' => 1
        );
        $this->db->insert('warehouse', $warehouse_data);

        return $store_id;
    }

    // other methods remain unchanged...
}
?>
